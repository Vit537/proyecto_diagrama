package com.example.dto;

import jakarta.validation.constraints.*;
import java.time.LocalDateTime;

public class Tabla1DTO {
    
    private Integer id;
    @NotNull
    private String nombre;

    // Default constructor
    public Tabla1DTO() {}

    // Getters and Setters
    public Integer getId() {
        return id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}