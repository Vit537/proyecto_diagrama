package com.example.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "tabla1")
public class Tabla1 {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(nullable = false)
    @NotNull
    private Integer id;
    @Column(nullable = false)
    @NotNull
    private String nombre;

    // Default constructor
    public Tabla1() {}

    // Constructor with fields
    public Tabla1(String nombre) {
        this.nombre = nombre;
    }

    // Getters and Setters
    public Integer getId() {
        return id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}