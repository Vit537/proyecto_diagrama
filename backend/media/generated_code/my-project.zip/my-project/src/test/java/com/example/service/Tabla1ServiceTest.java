package com.example.service;

import com.example.entity.Tabla1;
import com.example.repository.Tabla1Repository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest
public class Tabla1ServiceTest {
    
    @Mock
    private Tabla1Repository tabla1Repository;
    
    @InjectMocks
    private Tabla1Service tabla1Service;
    
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }
    
    @Test
    void testFindAll() {
        // Given
        Tabla1 tabla11 = new Tabla1();
        Tabla1 tabla12 = new Tabla1();
        List<Tabla1> tabla1s = Arrays.asList(tabla11, tabla12);
        
        when(tabla1Repository.findAll()).thenReturn(tabla1s);
        
        // When
        List<Tabla1> result = tabla1Service.findAll();
        
        // Then
        assertEquals(2, result.size());
        verify(tabla1Repository).findAll();
    }
    
    @Test
    void testFindById() {
        // Given
        Long id = 1L;
        Tabla1 tabla1 = new Tabla1();
        when(tabla1Repository.findById(id)).thenReturn(Optional.of(tabla1));
        
        // When
        Optional<Tabla1> result = tabla1Service.findById(id);
        
        // Then
        assertTrue(result.isPresent());
        verify(tabla1Repository).findById(id);
    }
}