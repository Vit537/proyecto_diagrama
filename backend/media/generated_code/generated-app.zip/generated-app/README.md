# Generated App

Generated Spring Boot application from UML diagram.

## Description
This application was automatically generated from a UML diagram using the UML Collaborative Diagram Platform (UMLCDP).

## Technology Stack
- Spring Boot 3.2.0
- Java 17
- Spring Data JPA
- PostgreSQL
- OpenAPI 3 / Swagger

## Getting Started

### Prerequisites
- Java 17 or higher
- Maven 3.6+
- PostgreSQL database

### Installation
1. Clone this repository
2. Configure your database connection in `src/main/resources/application.properties`
3. Run `mvn clean install`
4. Run `mvn spring-boot:run`

### API Documentation
The API documentation is available at http://localhost:8080/swagger-ui.html

## Generated Files
This project includes:
- Entity classes mapped to database tables
- Repository interfaces for data access
- Service classes for business logic
- REST controllers for API endpoints
- DTO classes for data transfer
- Test classes for unit testing

## Database Schema
The application expects a PostgreSQL database with tables corresponding to the UML diagram elements.

Generated on: 2025-09-29 04:19:13
