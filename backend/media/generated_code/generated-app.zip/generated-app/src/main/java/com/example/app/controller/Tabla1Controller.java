package com.example.app.controller;

import com.example.app.entity.Tabla1;
import com.example.app.service.Tabla1Service;
import com.example.app.dto.Tabla1DTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import java.util.List;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/tabla1")
@CrossOrigin(origins = "*")
@Tag(name = "Tabla1", description = "Tabla1 management APIs")
public class Tabla1Controller {
    
    @Autowired
    private Tabla1Service tabla1Service;
    
    @Operation(summary = "Get all tabla1s")
    @GetMapping
    public ResponseEntity<List<Tabla1>> getAllTabla1s() {
        List<Tabla1> tabla1s = tabla1Service.findAll();
        return ResponseEntity.ok(tabla1s);
    }
    
    @Operation(summary = "Get tabla1 by ID")
    @GetMapping("/{id}")
    public ResponseEntity<Tabla1> getTabla1ById(@PathVariable Integer id) {
        return tabla1Service.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    
    @Operation(summary = "Create new tabla1")
    @PostMapping
    public ResponseEntity<Tabla1> createTabla1(@Valid @RequestBody Tabla1DTO tabla1DTO) {
        Tabla1 createdTabla1 = tabla1Service.create(tabla1DTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdTabla1);
    }
    
    @Operation(summary = "Update tabla1")
    @PutMapping("/{id}")
    public ResponseEntity<Tabla1> updateTabla1(@PathVariable Integer id, 
                                                      @Valid @RequestBody Tabla1DTO tabla1DTO) {
        return tabla1Service.update(id, tabla1DTO)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    
    @Operation(summary = "Delete tabla1")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTabla1(@PathVariable Integer id) {
        if (tabla1Service.deleteById(id)) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}