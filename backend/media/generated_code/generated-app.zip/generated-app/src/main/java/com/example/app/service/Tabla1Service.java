package com.example.app.service;

import com.example.app.entity.Tabla1;
import com.example.app.repository.Tabla1Repository;
import com.example.app.dto.Tabla1DTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class Tabla1Service {
    
    @Autowired
    private Tabla1Repository tabla1Repository;
    
    public List<Tabla1> findAll() {
        return tabla1Repository.findAll();
    }
    
    public Optional<Tabla1> findById(Integer id) {
        return tabla1Repository.findById(id);
    }
    
    public Tabla1 save(Tabla1 tabla1) {
        return tabla1Repository.save(tabla1);
    }
    
    public Tabla1 create(Tabla1DTO tabla1DTO) {
        Tabla1 tabla1 = convertToEntity(tabla1DTO);
        return tabla1Repository.save(tabla1);
    }
    
    public Optional<Tabla1> update(Integer id, Tabla1DTO tabla1DTO) {
        return tabla1Repository.findById(id)
                .map(tabla1 -> {
                    updateEntityFromDTO(tabla1, tabla1DTO);
                    return tabla1Repository.save(tabla1);
                });
    }
    
    public boolean deleteById(Integer id) {
        if (tabla1Repository.existsById(id)) {
            tabla1Repository.deleteById(id);
            return true;
        }
        return false;
    }
    
    private Tabla1 convertToEntity(Tabla1DTO dto) {
        // Convert DTO to Entity
        Tabla1 entity = new Tabla1();
        // Set fields from DTO
        return entity;
    }
    
    private void updateEntityFromDTO(Tabla1 entity, Tabla1DTO dto) {
        // Update entity fields from DTO
    }
}