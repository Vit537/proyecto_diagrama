package com.example.app.repository;

import com.example.app.entity.Tabla1;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface Tabla1Repository extends JpaRepository<Tabla1, Integer> {
    
    // Custom query methods can be added here
    // Example: List<Tabla1> findByStatus(String status);
}